# Ball Bearing > TestV2
https://universe.roboflow.com/pathara-garagate/ball-bearing-94w8q

Provided by a Roboflow user
License: MIT

